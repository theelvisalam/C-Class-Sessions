﻿namespace Commenting;
using System;
using static System.Console;
/*
Michael Wu
Block Comment
adsfadf
*/
class Program
{
    /// <summary>
    ///   The main method for the console app (XMLDOC).
    /// </summary>
    /// <param name="args">arguments</param>
    static void Main(string[] args)
    {
        // Print a statement
        System.Console.WriteLine("Hello, World!");
        Console.WriteLine("Hello, World!");
        WriteLine("Hello");
        
    }
}
