﻿Console.WriteLine("Please enter an integer");
int num = Convert.ToInt32(Console.ReadLine());

if (num % 2 == 0)
{
    Console.WriteLine("This is a positive number");
}
else
{
    Console.WriteLine("This is a negative number");
}

